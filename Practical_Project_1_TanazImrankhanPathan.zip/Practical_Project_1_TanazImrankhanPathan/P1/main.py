import csv

print(f"Program by: Tanaz Pathan\n")

# Step 1: Create a record object
class Record:
    def __init__(self, column1, column2, column3):
        self.column1 = column1
        self.column2 = column2
        self.column3 = column3

    def __str__(self):
        return f"{self.column1}, {self.column2}, {self.column3}"

# Step 2: File I/O to read the dataset and initialize record objects
def load_records_from_csv(file_path):
    records = []
    try:
        with open(file_path, "r") as csvfile:
            reader = csv.reader(csvfile)
            header = next(reader)  # Skip the header row
            for row in reader:
                if len(row) >= 3:  # Ensure there are enough columns
                    record = Record(row[0], row[1], row[2])
                    records.append(record)
    except FileNotFoundError:
        print(f"Error: The file '{file_path}' was not found.")
    except Exception as e:
        print(f"Error: An unexpected error occurred: {e}")
    return records

# Step 3: Loop over the data structure and output the record data
def display_records(records):
    if not records:
        print("No records to display.")
        return
    print("Displaying Records:")
    for record in records:
        print(record)

# Main Program
if __name__ == "__main__":
    # File path for the dataset
    file_path = "Licensed_Early_Learning_and_Childcare_Facilities.csv"  # Update this to the actual CSV file path

    # Load records from the CSV file
    records = load_records_from_csv(file_path)

    # Display the records on screen
    display_records(records)
